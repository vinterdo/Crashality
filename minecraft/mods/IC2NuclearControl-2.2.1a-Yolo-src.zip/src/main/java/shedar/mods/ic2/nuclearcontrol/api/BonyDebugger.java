package shedar.mods.ic2.nuclearcontrol.api;

/**
 * Used for xbony2's debugging purposes. This is a very serious class, do not
 * make jokes about it.
 * 
 * @author xbony2
 */
public class BonyDebugger {

	/**
	 * Debugs stuff.
	 * 
	 * @author xbony2
	 */
	public static void debug() {
		System.out.println("YOLOYOLYOYOLOYOLYOYLYOYL");
		System.out.println("YOLOYOLYOYOLOYOLYOYLYOYL");
		System.out.println("YOLOYOLYOYOLOYOLYOYLYOYL");
		System.out.println("YOLOYOLYOYOLOYOLYOYLYOYL");
		System.out.println("YOLOYOLYOYOLOYOLYOYLYOYL");
		System.out.println("YOLOYOLYOYOLOYOLYOYLYOYL");
		System.out.println("YOLOYOLYOYOLOYOLYOYLYOYL");
		System.out.println("End of yolo spam.");
	}
}
