@API(owner = "IC2NuclearControl", apiVersion = "v1.0.5", provides = "NuclearControlAPI")
/**
 * Please do not distribute this package. Distributing other people's APIs
 * is always bad.
 */
package shedar.mods.ic2.nuclearcontrol.api;

import cpw.mods.fml.common.API;

