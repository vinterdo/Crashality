package shedar.mods.ic2.nuclearcontrol;

public interface IRedstoneConsumer {
	boolean getPowered();

	void setPowered(boolean value);

}
