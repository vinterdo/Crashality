package shedar.mods.ic2.nuclearcontrol;

public interface ITextureHelper {
	int modifyTextureIndex(int texture);
}
