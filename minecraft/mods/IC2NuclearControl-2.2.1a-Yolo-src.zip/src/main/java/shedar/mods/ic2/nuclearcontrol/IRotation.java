package shedar.mods.ic2.nuclearcontrol;

public interface IRotation {
	void rotate();

	int getRotation();

	void setRotation(int rotation);

	short getFacing();
}
