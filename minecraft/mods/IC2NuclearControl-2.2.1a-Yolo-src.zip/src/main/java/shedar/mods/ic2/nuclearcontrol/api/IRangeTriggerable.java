package shedar.mods.ic2.nuclearcontrol.api;

/**
 * 
 * Basic API for making a card be able to be used by the range trigger.
 * 
 * @author xbony2
 */
public interface IRangeTriggerable {
}
